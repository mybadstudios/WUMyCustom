<?php

//load this first as this makes sure the WP themes are not processed
$include_path = dirname(__FILE__) . "/../wub_login/settings.php";
include_once($include_path);

function customIsSubscribed() {
	$expiry = get_user_meta( get_current_user_id(), Posted('gid').'_sub_expiry_date', true);
	if (trim($expiry) == '') $expiry = 0;
	$subscribed = (intval($expiry) > time());
	SendToUnity(SendField("subscribed", $subscribed ? 'true' : 'false'));
}

function customGetCustomerPurchaseHistory()
{
    global $current_user;
    $args = array(
        'numberposts' => -1,
        'meta_key' => '_customer_user',
        'meta_value' => $current_user->ID,
        'post_type' => wc_get_order_types(),
        'post_status' => array_keys(wc_get_is_paid_statuses()),
    );
    $customer_orders = get_posts($args);
    
    $response = '';
    if (!$customer_orders) {
        SendToUnity(PrintError("No products purchased"));
        return;
    }

    foreach ($customer_orders as $customer_order) {
        $order = wc_get_order($customer_order->ID);
        $items = $order->get_items();
        foreach ($items as $item) {
            $response .= SendNode("Product", "product_id={$item->get_product_id()}");
            $response .= SendField("Name", $item->get_name());
        }
        SendToUnity($response);
    }
}

