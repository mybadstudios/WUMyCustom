<?php

session_start();

/*
Plugin Name: WUB My Custom Expansions
Plugin URI: https://wuss.mybadstudios.com/
Description: Extend the WordPress for Unity Bridge assets without fear of your code being deleted during updates
Version: 2.0
Network: true
Author: myBad Studios
Author URI: https://www.mybadstudios.com
*/

include_once(dirname(__FILE__) ."/wub_subscription_purchases.php");

add_filter( 'get_avatar' , 'use_custom_avatar_from_unity' , 10 , 5);
function use_custom_avatar_from_unity( $avatar, $id_or_email, $size, $default, $alt)
{
   $user = false;
    if ( is_numeric( $id_or_email ) )
    {
        $id = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
        
    } elseif ( is_object( $id_or_email ) )
    {
        
        if ( ! empty( $id_or_email->user_id ) )
        {
            $id = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }
        
    }
    else
    {
        $user = get_user_by( 'email', $id_or_email );
    }
    
    if ( $user && is_object( $user ) )
    {
        $found = '';
        $base_path = "/wp-content/uploads/{$user->data->user_login}/myavatar.";
        if (file_exists(ABSPATH .$base_path . 'jpg')) $found = 'jpg';
        else if (file_exists(ABSPATH .$base_path . 'png')) $found = 'png';
        if ($found != '')
            $avatar =  "<img alt='{$alt}' src='{$base_path}{$found}' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
    }
    return $avatar;
}