<?php

//load this first as this makes sure the WP themes are not processed
include_once(dirname(__FILE__) . "/../wuss_login/settings.php");

function customIsSubscribed() {
	$expiry = get_user_meta( get_current_user_id(), Posted('gid').'_sub_expiry_date', true);
	if (trim($expiry) == '') $expiry = 0;
	$subscribed = (intval($expiry) > time());
	SendToUnity(SendField("subscribed", $subscribed ? 'true' : 'false'));
}
